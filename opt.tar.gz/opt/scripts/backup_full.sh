#!/bin/bash

mostrar_ayuda() {
	echo "Uso: $0 origen destino"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Este script genera un backup y lo guarda en el destino con fecha en formato YYYYMMDD."
}

if [[ "$1" == "-help" ]]; then
	mostrar_ayuda
	exit 0
fi

if [[ $# -ne 2 ]]; then
	echo "Error: se debe proporcionar un origen y un destino."
	mostrar_ayuda
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen $ORIGEN no existe."
	exit 1
fi

if ! mountpoint -q "$DESTINO"; then
	echo "Error: El destino $DESTINO no esta montado."
	exit 1
fi

NOMBRE_DIR=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [[ $? -eq 0 ]]; then
	echo "Backup de $ORIGEN guardado como $DESTINO/$ARCHIVO"
else
	echo "Error al realizar backup."
	exit1
fi
